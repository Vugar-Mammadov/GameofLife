cmake -B build && cd build && make && make dist && mv GameofLife ~/Desktop/GameofLife && mv GameofLife.tar.gz ~/Desktop/GameofLife && rm -rf * && rmdir /build
