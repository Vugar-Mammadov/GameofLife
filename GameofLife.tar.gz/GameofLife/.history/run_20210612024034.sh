cmake -B build && cd build && make && make dist && mv GameofLife ~/Desktop/GameofLife && mv GameofLife.tar.gz ~/Desktop/GameofLife && cd build && rm -rf * && rmdir build
