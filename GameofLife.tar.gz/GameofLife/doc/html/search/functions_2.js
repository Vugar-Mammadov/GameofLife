var searchData=
[
  ['create_5f2d_5farray_33',['create_2D_array',['../life_8c.html#a833a732aee642e0e758f8adfb7671b39',1,'create_2D_array(int nrow, int ncol):&#160;life.c'],['../life_8h.html#a833a732aee642e0e758f8adfb7671b39',1,'create_2D_array(int nrow, int ncol):&#160;life.c']]]
];
