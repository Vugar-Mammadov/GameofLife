var searchData=
[
  ['reset_30',['reset',['../life_8h.html#a01de9e6a115c86e1c2b8747df2b28925',1,'life.h']]]
];
