var searchData=
[
  ['cellstate_4',['cellState',['../life_8h.html#a38e97bf4503f8099c49fac77b951ae63',1,'life.h']]],
  ['create_5f2d_5farray_5',['create_2D_array',['../life_8c.html#a833a732aee642e0e758f8adfb7671b39',1,'create_2D_array(int nrow, int ncol):&#160;life.c'],['../life_8h.html#a833a732aee642e0e758f8adfb7671b39',1,'create_2D_array(int nrow, int ncol):&#160;life.c']]]
];
