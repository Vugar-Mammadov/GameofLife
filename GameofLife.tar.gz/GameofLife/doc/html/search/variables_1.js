var searchData=
[
  ['ncol_44',['ncol',['../structboard.html#ac5491860d728554e3f359de6ec57390f',1,'board']]],
  ['nrow_45',['nrow',['../structboard.html#aa4f47f749a6336c7364147e7c7c4a8cc',1,'board']]]
];
