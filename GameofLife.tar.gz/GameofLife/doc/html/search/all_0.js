var searchData=
[
  ['aliveneighbourscount_0',['aliveNeighboursCount',['../life_8c.html#a427628ae6011d8c77f4dfe54a8b48d3d',1,'aliveNeighboursCount(int row, int col, Board *b):&#160;life.c'],['../life_8h.html#a427628ae6011d8c77f4dfe54a8b48d3d',1,'aliveNeighboursCount(int row, int col, Board *b):&#160;life.c']]]
];
