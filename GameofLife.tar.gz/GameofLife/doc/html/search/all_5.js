var searchData=
[
  ['game_11',['game',['../life_8c.html#a35a1901d1fa391ce4c54ca48f1e72504',1,'game(Board *b_t, int maxIter):&#160;life.c'],['../life_8h.html#a35a1901d1fa391ce4c54ca48f1e72504',1,'game(Board *b_t, int maxIter):&#160;life.c']]],
  ['gamegrid_12',['gameGrid',['../structboard.html#a3d7a1b3f9e54eead551533a32ad3f81c',1,'board']]],
  ['gameoflife_13',['GameofLife',['../md_README.html',1,'']]]
];
