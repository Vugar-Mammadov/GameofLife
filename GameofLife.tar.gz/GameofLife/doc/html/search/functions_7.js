var searchData=
[
  ['nextstate_42',['nextState',['../life_8c.html#ab4da00242e098f7e2e290cd9ea89ff1b',1,'nextState(int row, int col, Board *b_t):&#160;life.c'],['../life_8h.html#ab4da00242e098f7e2e290cd9ea89ff1b',1,'nextState(int row, int col, Board *b_t):&#160;life.c']]]
];
