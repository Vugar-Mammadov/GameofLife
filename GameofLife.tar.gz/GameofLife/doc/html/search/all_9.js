var searchData=
[
  ['ncol_21',['ncol',['../structboard.html#ac5491860d728554e3f359de6ec57390f',1,'board']]],
  ['ncol_5fdef_22',['NCOL_DEF',['../life_8h.html#a2e92020d9876185d5b3a482ccd11943e',1,'life.h']]],
  ['nextstate_23',['nextState',['../life_8c.html#ab4da00242e098f7e2e290cd9ea89ff1b',1,'nextState(int row, int col, Board *b_t):&#160;life.c'],['../life_8h.html#ab4da00242e098f7e2e290cd9ea89ff1b',1,'nextState(int row, int col, Board *b_t):&#160;life.c']]],
  ['nrow_24',['nrow',['../structboard.html#aa4f47f749a6336c7364147e7c7c4a8cc',1,'board']]],
  ['nrow_5fdef_25',['NROW_DEF',['../life_8h.html#a7a52bcad564f9194062663c9b2c2ed81',1,'life.h']]]
];
