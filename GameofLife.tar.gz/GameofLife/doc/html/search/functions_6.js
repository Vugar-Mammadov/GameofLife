var searchData=
[
  ['initboard_40',['initBoard',['../life_8c.html#aace6acff2f83340f3ac4dda6f449cccc',1,'initBoard(int nrow, int ncol):&#160;life.c'],['../life_8h.html#aace6acff2f83340f3ac4dda6f449cccc',1,'initBoard(int nrow, int ncol):&#160;life.c']]],
  ['issame_41',['isSame',['../life_8c.html#afe0ffc74b22cbcca39d78a4b59a1842c',1,'isSame(Board *b1, Board *b2):&#160;life.c'],['../life_8h.html#afe0ffc74b22cbcca39d78a4b59a1842c',1,'isSame(Board *b1, Board *b2):&#160;life.c']]]
];
