var searchData=
[
  ['main_2ec_18',['main.c',['../main_8c.html',1,'']]],
  ['max_5fiter_5fdef_19',['MAX_ITER_DEF',['../life_8h.html#a44dd355f04f16726e6f0c4e25d801fe0',1,'life.h']]],
  ['min_5fnb_5frows_5fcols_20',['MIN_NB_ROWS_COLS',['../life_8h.html#a279b5f009ec657a2a6760e2012d285b9',1,'life.h']]]
];
