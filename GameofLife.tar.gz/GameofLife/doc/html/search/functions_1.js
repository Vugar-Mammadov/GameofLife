var searchData=
[
  ['board_5ft1_32',['board_t1',['../life_8c.html#a5aa2557643d946b2e11b9ad55ecfde4d',1,'board_t1(Board *board_t):&#160;life.c'],['../life_8h.html#a5aa2557643d946b2e11b9ad55ecfde4d',1,'board_t1(Board *board_t):&#160;life.c']]]
];
