var searchData=
[
  ['life_2ec_16',['life.c',['../life_8c.html',1,'']]],
  ['life_2eh_17',['life.h',['../life_8h.html',1,'']]]
];
