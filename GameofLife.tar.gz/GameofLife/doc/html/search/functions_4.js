var searchData=
[
  ['fill_5fmatrix_36',['fill_matrix',['../life_8c.html#afcfd51ce2014ab0cf9f21385f8b2cc6f',1,'fill_matrix(int n, int **matrix, int nrow, int ncol):&#160;life.c'],['../life_8h.html#afcfd51ce2014ab0cf9f21385f8b2cc6f',1,'fill_matrix(int n, int **matrix, int nrow, int ncol):&#160;life.c']]],
  ['fill_5fmatrix_5frandom_37',['fill_matrix_random',['../life_8c.html#ab1a65a442b9e25e8fa0b87855749f773',1,'fill_matrix_random(int **matrix, int nrow, int ncol):&#160;life.c'],['../life_8h.html#ab1a65a442b9e25e8fa0b87855749f773',1,'fill_matrix_random(int **matrix, int nrow, int ncol):&#160;life.c']]],
  ['fillboard_38',['fillBoard',['../life_8c.html#aa442ab3f908043c12dc9572f8f8e0310',1,'fillBoard(Board *b, bool fillRandom):&#160;life.c'],['../life_8h.html#aa442ab3f908043c12dc9572f8f8e0310',1,'fillBoard(Board *b, bool fillRandom):&#160;life.c']]]
];
