var searchData=
[
  ['deadboard_34',['deadBoard',['../life_8c.html#a82189efe80d48dd305d62740cf216ca7',1,'deadBoard(Board *b):&#160;life.c'],['../life_8h.html#a82189efe80d48dd305d62740cf216ca7',1,'deadBoard(Board *b):&#160;life.c']]],
  ['deleteboard_35',['deleteBoard',['../life_8c.html#aaa781ad22c18796d59204102c0808669',1,'deleteBoard(Board *b):&#160;life.c'],['../life_8h.html#aaa781ad22c18796d59204102c0808669',1,'deleteBoard(Board *b):&#160;life.c']]]
];
