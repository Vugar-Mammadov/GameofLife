var searchData=
[
  ['print_5fboard_49',['print_board',['../life_8c.html#a5b72251d9d957e84126f7da314756202',1,'print_board(Board *b):&#160;life.c'],['../life_8h.html#a5b72251d9d957e84126f7da314756202',1,'print_board(Board *b):&#160;life.c']]]
];
