var searchData=
[
  ['ncol_5fdef_50',['NCOL_DEF',['../life_8h.html#a2e92020d9876185d5b3a482ccd11943e',1,'life.h']]],
  ['nrow_5fdef_51',['NROW_DEF',['../life_8h.html#a7a52bcad564f9194062663c9b2c2ed81',1,'life.h']]]
];
